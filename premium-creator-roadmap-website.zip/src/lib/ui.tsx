import React from 'react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const Section = ({ children, className, id }: { children: React.ReactNode; className?: string; id?: string }) => (
  <section id={id} className={cn("py-24 px-6 md:px-12 max-w-5xl mx-auto w-full", className)}>
    {children}
  </section>
);

export const Card = ({ children, className }: { children: React.ReactNode; className?: string }) => (
  <div className={cn("bg-zinc-900/50 border border-zinc-800 p-6 rounded-2xl", className)}>
    {children}
  </div>
);

export const Badge = ({ children, className }: { children: React.ReactNode; className?: string }) => (
  <span className={cn("px-3 py-1 text-xs font-medium rounded-full border border-zinc-700 text-zinc-400", className)}>
    {children}
  </span>
);
