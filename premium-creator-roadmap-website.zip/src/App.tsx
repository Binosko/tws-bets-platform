import React from 'react';
import { motion } from 'framer-motion';
import { 
  ArrowRight, 
  AlertTriangle, 
  BarChart3, 
  CheckCircle2, 
  Eye, 
  MessageSquare, 
  Zap, 
  ShieldCheck, 
  Award, 
  Users,
  Flame,
  XCircle,
  TrendingDown
} from 'lucide-react';
import { Section, Card, Badge } from './lib/ui';
import { 
  FlowDiagram, 
  AuditMetric, 
  ComparisonCard, 
  RoadmapStep, 
  SocialMockup 
} from './components/Visuals';

const App = () => {
  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 font-sans selection:bg-zinc-700">
      {/* Hero Section */}
      <Section className="pt-32 pb-20 text-center">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Badge className="mb-6 bg-zinc-900 border-zinc-700 text-zinc-400">STRATEGIC OPERATOR DOCUMENT v1.0</Badge>
          <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-8 max-w-4xl mx-auto leading-tight">
            14 Day Audience <span className="text-zinc-500">Trust & Conversion</span> System
          </h1>
          <p className="text-xl text-zinc-400 max-w-2xl mx-auto leading-relaxed">
            Audience attention is already there. <br className="hidden md:block" />
            <span className="text-zinc-100 font-medium">The real problem is conversion psychology and trust depth.</span>
          </p>
        </motion.div>
      </Section>

      {/* The Core Logic Flow */}
      <Section className="pb-20">
        <div className="text-center mb-12">
          <h2 className="text-sm font-mono uppercase tracking-widest text-zinc-500 mb-4">The Value Pipeline</h2>
          <div className="h-px w-12 bg-zinc-700 mx-auto" />
        </div>
        <Card className="bg-zinc-900/30 border-zinc-800 py-12">
          <FlowDiagram steps={[
            { label: 'ATTENTION', sub: 'Reach & Visibility' },
            { label: 'TRUST', sub: 'Emotional Connection' },
            { label: 'AUTHORITY', sub: 'Category Positioning' },
            { label: 'COMMUNITY', sub: 'Loyalty & Retention' },
            { label: 'CONVERSION', sub: 'Buyer Confidence' },
          ]} />
        </Card>
      </Section>

      {/* Visual Creator Audit */}
      <Section>
        <div className="mb-16">
          <h2 className="text-3xl font-bold mb-4">Creator Audit: The Trust Gap</h2>
          <p className="text-zinc-400 max-w-2xl">
            Most creators with 30k-200k followers are trapped in the "Attention Loop"—high reach, but shallow trust. 
            This creates a conversion ceiling.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <AuditMetric label="Reach / Impressions" value="Strong" status="strong" trend="up" />
          <AuditMetric label="Audience Trust Depth" value="Weak" status="weak" trend="down" />
          <AuditMetric label="Conversion Rate" value="Inconsistent" status="weak" trend="down" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <Card className="p-8 bg-zinc-900/30 border-zinc-800">
            <div className="flex items-center gap-3 text-zinc-100 font-semibold mb-6">
              <BarChart3 size={20} className="text-zinc-500" />
              <h3>The Attention Paradox</h3>
            </div>
            <div className="space-y-6">
              <div className="space-y-2">
                <div className="flex justify-between text-xs text-zinc-500 mb-1">
                  <span>Follower Growth</span>
                  <span>High</span>
                </div>
                <div className="h-2 w-full bg-zinc-800 rounded-full overflow-hidden">
                  <div className="h-full w-full bg-zinc-100" />
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-xs text-zinc-500 mb-1">
                  <span>Emotional Connection</span>
                  <span>Low</span>
                </div>
                <div className="h-2 w-full bg-zinc-800 rounded-full overflow-hidden">
                  <div className="h-full w-1/4 bg-rose-500" />
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-xs text-zinc-500 mb-1">
                  <span>Authority Positioning</span>
                  <span>Moderate</span>
                </div>
                <div className="h-2 w-full bg-zinc-800 rounded-full overflow-hidden">
                  <div className="h-full w-1/3 bg-zinc-500" />
                </div>
              </div>
            </div>
            <p className="mt-6 text-xs text-zinc-500 leading-relaxed">
              Analysis: You are perceived as a "content source" rather than a "trusted advisor." 
              This results in high engagement but low buyer confidence.
            </p>
          </Card>

          <div className="flex flex-col justify-center gap-6">
            <div className="p-6 border border-zinc-800 rounded-2xl bg-zinc-900/20">
              <div className="flex items-center gap-3 text-rose-400 mb-3">
                <AlertTriangle size={18} />
                <span className="font-semibold text-sm">The Leakage Point</span>
              </div>
              <p className="text-sm text-zinc-400 leading-relaxed">
                The gap between <span className="text-zinc-100">Attention</span> and <span className="text-zinc-100">Trust</span> is where your potential revenue is disappearing. 
                Followers are consuming your content, but they aren't investing in your vision.
              </p>
            </div>
            <div className="p-6 border border-zinc-800 rounded-2xl bg-zinc-900/20">
              <div className="flex items-center gap-3 text-zinc-100 mb-3">
                <Zap size={18} className="text-zinc-500" />
                <span className="font-semibold text-sm">The Opportunity</span>
              </div>
              <p className="text-sm text-zinc-400 leading-relaxed">
                By shifting from "Entertainer" to "Operator," you can double conversion rates without adding a single new follower.
              </p>
            </div>
          </div>
        </div>
      </Section>

      {/* Roadmap */}
      <Section>
        <div className="text-center mb-20">
          <h2 className="text-4xl font-bold mb-4">The 14-Day Strategic Roadmap</h2>
          <p className="text-zinc-400 max-w-2xl mx-auto">
            A phased approach to repositioning your brand and deepening audience trust.
          </p>
        </div>

        {/* Phase 1 */}
        <div className="mb-32">
          <div className="flex items-center gap-4 mb-12">
            <div className="w-12 h-12 rounded-full bg-zinc-100 text-zinc-950 flex items-center justify-center font-bold text-lg">1</div>
            <div>
              <h3 className="text-2xl font-bold">Phase 1: Repositioning Attention</h3>
              <p className="text-zinc-500 text-sm">Days 1-3 • Shift perception from "Creator" to "Authority"</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            <div className="lg:col-span-7 space-y-12">
              <RoadmapStep 
                day="Day 1-3" 
                title="The Authority Shift" 
                goal="Break the 'content creator' mold"
                content={
                  <div className="space-y-6">
                    <p className="text-sm leading-relaxed">
                      Start by challenging the status quo of your niche. Instead of providing "tips," 
                      provide <span className="text-zinc-100 font-medium">strategic frameworks</span>.
                    </p>
                    <ComparisonCard 
                      weak={{
                        title: "Weak Content",
                        points: ["Generic motivation", "Fake guru flexing", "Surface-level advice", "Random viral clips"]
                      }}
                      strong={{
                        title: "Strong Content",
                        points: ["Emotional storytelling", "Strategic lessons", "Vulnerability + Authority", "Audience relatability"]
                      }}
                    />
                  </div>
                }
              />
              
              <div className="p-6 border border-zinc-800 rounded-2xl bg-zinc-900/30">
                <div className="flex items-center gap-2 text-zinc-100 font-semibold mb-4">
                  <MessageSquare size={18} className="text-zinc-500" />
                  <h4>Posting Structure</h4>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="p-3 rounded-lg bg-zinc-800/50 border border-zinc-700">
                    <div className="font-bold text-zinc-300 mb-1">1x Short-form Video</div>
                    <div className="text-zinc-500">Highly intentional, a single strong opinion.</div>
                  </div>
                  <div className="p-3 rounded-lg bg-zinc-800/50 border border-zinc-700">
                    <div className="font-bold text-zinc-300 mb-1">1x Thought-leader Post</div>
                    <div className="text-zinc-500">Deep dive into a lesson learned from failure.</div>
                  </div>
                  <div className="p-3 rounded-lg bg-zinc-800/50 border border-zinc-700">
                    <div className="font-bold text-zinc-300 mb-1">2-3 IG Stories</div>
                    <div className="text-zinc-500">Transparency on your current process.</div>
                  </div>
                  <div className="p-3 rounded-lg bg-zinc-800/50 border border-zinc-700">
                    <div className="font-bold text-zinc-300 mb-1">Active Interaction</div>
                    <div className="text-zinc-500">Comment replies that add extra value.</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-5 space-y-8">
              <div className="p-6 border border-zinc-800 rounded-2xl bg-zinc-900/50">
                <h4 className="text-sm font-bold mb-4 flex items-center gap-2">
                  <Eye size={16} className="text-zinc-500" />
                  Psychology Map
                </h4>
                <div className="flex flex-col gap-4">
                  <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/20 text-xs text-rose-300">
                    Attention without Trust = <span className="font-bold">Low Conversions</span>
                  </div>
                  <div className="text-center py-2 text-zinc-600">
                    <ArrowRight className="rotate-90 mx-auto" size={16} />
                  </div>
                  <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-300">
                    Attention + Emotional Connection = <span className="font-bold">High Intent</span>
                  </div>
                </div>
              </div>
              <SocialMockup 
                platform="Instagram" 
                content={
                  <div className="space-y-3">
                    <div className="aspect-square w-full bg-zinc-800 rounded-lg flex items-center justify-center text-zinc-600 text-xs italic px-4 text-center">
                      [Video: You sharing a specific failure and the 3-step system you used to fix it]
                    </div>
                    <div className="text-[10px] text-zinc-400 leading-relaxed">
                      "I spent 6 months building the wrong product. Here's why the 'perfect' launch is a lie and what I actually learned about buyer psychology..."
                    </div>
                  </div>
                }
              />
            </div>
          </div>
        </div>

        {/* Phase 2 */}
        <div className="mb-32">
          <div className="flex items-center gap-4 mb-12">
            <div className="w-12 h-12 rounded-full bg-zinc-100 text-zinc-950 flex items-center justify-center font-bold text-lg">2</div>
            <div>
              <h3 className="text-2xl font-bold">Phase 2: Trust Depth System</h3>
              <p className="text-zinc-500 text-sm">Days 4-7 • Build familiarity and emotional connection</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            <div className="lg:col-span-7 space-y-12">
              <RoadmapStep 
                day="Day 4-7" 
                title="The Familiarity Loop" 
                goal="Increase emotional resonance"
                content={
                  <div className="space-y-6">
                    <p className="text-sm leading-relaxed">
                      Trust is not a one-time event; it's a compounding asset. 
                      We build it through <span className="text-zinc-100 font-medium">Repetition, Transparency, and Consistency</span>.
                    </p>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 rounded-xl border border-zinc-800 bg-zinc-900/30">
                        <div className="text-xs font-bold text-zinc-300 mb-2">Trust Trigger A</div>
                        <div className="text-[11px] text-zinc-500 leading-relaxed">Sharing "Behind the scenes" systems and raw process.</div>
                      </div>
                      <div className="p-4 rounded-xl border border-zinc-800 bg-zinc-900/30">
                        <div className="text-xs font-bold text-zinc-300 mb-2">Trust Trigger B</div>
                        <div className="text-[11px] text-zinc-500 leading-relaxed">Publicly solving audience problems in real-time.</div>
                      </div>
                    </div>
                  </div>
                }
              />
              
              <div className="p-6 border border-zinc-800 rounded-2xl bg-zinc-900/30">
                <h4 className="text-sm font-bold mb-4">Trust-Building Systems</h4>
                <div className="space-y-3">
                  {[
                    "Audience Polls: Let them co-create your next project",
                    "Deep Q&A: Answer the 'uncomfortable' questions",
                    "Daily Systems: Show how you actually work",
                    "Personal Lessons: Share the philosophy behind the work"
                  ].map((item, i) => (
                    <div key={i} className="flex items-center gap-3 text-xs text-zinc-400">
                      <CheckCircle2 size={14} className="text-emerald-500" />
                      {item}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="lg:col-span-5 space-y-8">
              <Card className="bg-zinc-900/50 border-zinc-800 p-6">
                <div className="text-xs font-mono text-zinc-500 mb-6 text-center">TRUST COMPRESSION MODEL</div>
                <div className="flex flex-col items-center gap-3">
                  <div className="px-4 py-2 rounded-full border border-zinc-700 text-xs text-zinc-300 w-full text-center">Consistency</div>
                  <ArrowRight className="rotate-90 text-zinc-700" size={16} />
                  <div className="px-4 py-2 rounded-full border border-zinc-700 text-xs text-zinc-300 w-full text-center">Familiarity</div>
                  <ArrowRight className="rotate-90 text-zinc-700" size={16} />
                  <div className="px-4 py-2 rounded-full border border-zinc-700 text-xs text-zinc-300 w-full text-center">Trust</div>
                  <ArrowRight className="rotate-90 text-zinc-700" size={16} />
                  <div className="px-4 py-2 rounded-full bg-zinc-100 text-zinc-950 text-xs font-bold w-full text-center">Loyalty</div>
                </div>
              </Card>
              <SocialMockup 
                platform="Instagram Story" 
                type="story"
                content={
                  <div className="h-full flex flex-col justify-end pb-8 space-y-4">
                    <div className="p-3 bg-white/10 backdrop-blur-md rounded-lg border border-white/20 text-[10px] text-white">
                      "Which of these 3 frameworks is more confusing? Be honest."
                    </div>
                    <div className="flex justify-between gap-2">
                      <div className="w-1/2 h-12 rounded-lg border border-zinc-700 bg-zinc-800/50" />
                      <div className="w-1/2 h-12 rounded-lg border border-zinc-700 bg-zinc-800/50" />
                    </div>
                  </div>
                }
              />
            </div>
          </div>
        </div>

        {/* Phase 3 */}
        <div className="mb-32">
          <div className="flex items-center gap-4 mb-12">
            <div className="w-12 h-12 rounded-full bg-zinc-100 text-zinc-950 flex items-center justify-center font-bold text-lg">3</div>
            <div>
              <h3 className="text-2xl font-bold">Phase 3: Authority & Positioning</h3>
              <p className="text-zinc-500 text-sm">Days 8-10 • Position as the category leader</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            <div className="lg:col-span-7 space-y-12">
              <RoadmapStep 
                day="Day 8-10" 
                title="The Category Authority" 
                goal="Own a specific mental model"
                content={
                  <div className="space-y-6">
                    <p className="text-sm leading-relaxed">
                      Now that trust is established, we move from "relatable" to "authoritative." 
                      This is where you define <span className="text-zinc-100 font-medium">why your approach is the only one that works</span>.
                    </p>
                    <div className="space-y-4">
                      <div className="p-4 rounded-xl border border-zinc-800 bg-zinc-900/30">
                        <div className="text-xs font-bold text-zinc-300 mb-1">Authority Angle 1</div>
                        <div className="text-xs text-zinc-500">"What most creators misunderstand about audience trust."</div>
                      </div>
                      <div className="p-4 rounded-xl border border-zinc-800 bg-zinc-900/30">
                        <div className="text-xs font-bold text-zinc-300 mb-1">Authority Angle 2</div>
                        <div className="text-xs text-zinc-500">"Why most digital products fail emotionally."</div>
                      </div>
                      <div className="p-4 rounded-xl border border-zinc-800 bg-zinc-900/30">
                        <div className="text-xs font-bold text-zinc-300 mb-1">Authority Angle 3</div>
                        <div className="text-xs text-zinc-500">"How creator consistency affects buying behavior."</div>
                      </div>
                    </div>
                  </div>
                }
              />
              
              <div className="p-6 border border-zinc-800 rounded-2xl bg-zinc-900/30">
                <div className="flex items-center gap-2 text-zinc-100 font-semibold mb-4">
                  <Award size={18} className="text-zinc-500" />
                  <h4>Authority Content Mix</h4>
                </div>
                <div className="space-y-3 text-xs">
                  <div className="flex justify-between p-3 rounded-lg bg-zinc-800/50 border border-zinc-700">
                    <span className="text-zinc-400">Authority-based Shorts</span>
                    <span className="text-zinc-100 font-mono">1x Daily</span>
                  </div>
                  <div className="flex justify-between p-3 rounded-lg bg-zinc-800/50 border border-zinc-700">
                    <span className="text-zinc-400">Deep Educational Threads</span>
                    <span className="text-zinc-100 font-mono">1x / 2 Days</span>
                  </div>
                  <div className="flex justify-between p-3 rounded-lg bg-zinc-800/50 border border-zinc-700">
                    <span className="text-zinc-400">Social Proof Case Studies</span>
                    <span className="text-zinc-100 font-mono">2x Weekly</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-5 space-y-8">
              <div className="p-6 border border-zinc-800 rounded-2xl bg-zinc-900/50">
                <div className="text-xs font-mono text-zinc-500 mb-6 text-center">PERCEPTION MAP</div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl border border-zinc-800 bg-zinc-900 text-center">
                    <div className="text-[10px] text-zinc-500 mb-2">ENTERTAINER</div>
                    <div className="text-xs font-bold text-zinc-400">High Reach / Low Price</div>
                  </div>
                  <div className="p-4 rounded-xl border border-emerald-900/30 bg-emerald-950/10 text-center">
                    <div className="text-[10px] text-emerald-500 mb-2">AUTHORITY</div>
                    <div className="text-xs font-bold text-emerald-400">High Trust / High Price</div>
                  </div>
                </div>
              </div>
              <SocialMockup 
                platform="X / Twitter" 
                content={
                  <div className="space-y-3">
                    <div className="text-xs font-bold text-zinc-100">The Trust Paradox 🧵</div>
                    <div className="text-[10px] text-zinc-400 leading-relaxed">
                      Most creators think more followers = more sales. <br /><br />
                      Wrong. <br /><br />
                      1,000 people who trust your framework are worth more than 100,000 people who like your edits. <br /><br />
                      Here is the 3-part system for building depth... (1/12)
                    </div>
                  </div>
                }
              />
            </div>
          </div>
        </div>

        {/* Phase 4 */}
        <div className="mb-32">
          <div className="flex items-center gap-4 mb-12">
            <div className="w-12 h-12 rounded-full bg-zinc-100 text-zinc-950 flex items-center justify-center font-bold text-lg">4</div>
            <div>
              <h3 className="text-2xl font-bold">Phase 4: Community & Conversion</h3>
              <p className="text-zinc-500 text-sm">Days 11-14 • Turn trust into buyer confidence</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            <div className="lg:col-span-7 space-y-12">
              <RoadmapStep 
                day="Day 11-14" 
                title="The Conversion Engine" 
                goal="Monetize the depth of trust"
                content={
                  <div className="space-y-6">
                    <p className="text-sm leading-relaxed">
                      Buyers don't buy products; they buy <span className="text-zinc-100 font-medium">certainty</span>. 
                      When emotional trust and authority align, the sale becomes a natural conclusion.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 rounded-xl border border-zinc-800 bg-zinc-900/30">
                        <div className="text-xs font-bold text-zinc-300 mb-2 flex items-center gap-2">
                          <ShieldCheck size={14} className="text-emerald-500" />
                          Soft CTA
                        </div>
                        <div className="text-[11px] text-zinc-500 italic">"DM me 'START' and I'll send the framework."</div>
                      </div>
                      <div className="p-4 rounded-xl border border-zinc-800 bg-zinc-900/30">
                        <div className="text-xs font-bold text-zinc-300 mb-2 flex items-center gap-2">
                          <XCircle size={14} className="text-rose-500" />
                          Hard Sell
                        </div>
                        <div className="text-[11px] text-zinc-500 italic">"Buy my course now for 50% off!"</div>
                      </div>
                    </div>
                  </div>
                }
              />
              
              <div className="p-6 border border-zinc-800 rounded-2xl bg-zinc-900/30">
                <h4 className="text-sm font-bold mb-6">The High-Trust Funnel</h4>
                <div className="space-y-4">
                  <div className="flex items-center gap-4 p-3 rounded-lg bg-zinc-800/30 border border-zinc-700/50">
                    <div className="w-8 h-8 rounded-full bg-zinc-700 flex items-center justify-center text-[10px] font-bold">TikTok</div>
                    <ArrowRight size={14} className="text-zinc-600" />
                    <div className="w-8 h-8 rounded-full bg-zinc-700 flex items-center justify-center text-[10px] font-bold">IG</div>
                    <ArrowRight size={14} className="text-zinc-600" />
                    <div className="px-3 py-1 rounded-full bg-zinc-100 text-zinc-950 text-[10px] font-bold">Product</div>
                  </div>
                  <div className="flex items-center gap-4 p-3 rounded-lg bg-zinc-800/30 border border-zinc-700/50">
                    <div className="w-8 h-8 rounded-full bg-zinc-700 flex items-center justify-center text-[10px] font-bold">X</div>
                    <ArrowRight size={14} className="text-zinc-600" />
                    <div className="w-8 h-8 rounded-full bg-zinc-700 flex items-center justify-center text-[10px] font-bold">Community</div>
                    <ArrowRight size={14} className="text-zinc-600" />
                    <div className="px-3 py-1 rounded-full bg-zinc-100 text-zinc-950 text-[10px] font-bold">High-Ticket</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:col-span-5 space-y-8">
              <Card className="bg-zinc-900/50 border-zinc-800 p-6">
                <div className="text-xs font-mono text-zinc-500 mb-6 text-center">CONVERSION PSYCHOLOGY</div>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-2 border-b border-zinc-800">
                    <span className="text-xs text-zinc-400">Emotional Trust</span>
                    <span className="text-xs text-emerald-500 font-bold">REQUIRED</span>
                  </div>
                  <div className="flex justify-between items-center p-2 border-b border-zinc-800">
                    <span className="text-xs text-zinc-400">Category Authority</span>
                    <span className="text-xs text-emerald-500 font-bold">REQUIRED</span>
                  </div>
                  <div className="flex justify-between items-center p-2 border-b border-zinc-800">
                    <span className="text-xs text-zinc-400">Consistent Presence</span>
                    <span className="text-xs text-emerald-500 font-bold">REQUIRED</span>
                  </div>
                  <div className="mt-4 p-3 rounded-lg bg-zinc-100 text-zinc-950 text-center text-xs font-bold">
                    RESULT: BUYER TRUST
                  </div>
                </div>
              </Card>
              <div className="p-6 border border-zinc-800 rounded-2xl bg-zinc-900/50">
                <div className="flex items-center gap-2 text-zinc-100 font-semibold mb-4">
                  <Users size={18} className="text-zinc-500" />
                  <h4 className="text-sm">Community Retention</h4>
                </div>
                <p className="text-xs text-zinc-400 leading-relaxed">
                  Conversion is the start, not the end. Retention is built by continuing the trust loop 
                  inside the product. The product should feel like an extension of the authority.
                </p>
              </div>
            </div>
          </div>
        </div>
      </Section>

      {/* Final Section: Plateau */}
      <Section className="pb-32">
        <div className="text-center mb-20">
          <h2 className="text-4xl font-bold mb-4">Why Most Creators Plateau</h2>
          <p className="text-zinc-400 max-w-2xl mx-auto">
            The difference between a "Viral Creator" and a "Category Authority" is structural.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { 
              title: "Audience Fatigue", 
              desc: "Posting the same value-hooks for 2 years without deepening the emotional connection.",
              icon: <Flame className="text-rose-500" /> 
            },
            { 
              title: "Inconsistent Positioning", 
              desc: "Switching niches or tones based on what 'goes viral' instead of what builds authority.",
              icon: <AlertTriangle className="text-amber-500" /> 
            },
            { 
              title: "Over-Selling", 
              desc: "Prioritizing the CTA over the Trust Loop, leading to a decline in audience receptivity.",
              icon: <TrendingDown className="text-zinc-500" /> 
            },
          ].map((item, i) => (
            <Card key={i} className="p-8 bg-zinc-900/30 border-zinc-800 flex flex-col items-center text-center">
              <div className="mb-4">{item.icon}</div>
              <h4 className="text-lg font-semibold mb-2">{item.title}</h4>
              <p className="text-sm text-zinc-500 leading-relaxed">{item.desc}</p>
            </Card>
          ))}
        </div>

        <div className="mt-24 p-12 rounded-3xl border border-zinc-800 bg-gradient-to-b from-zinc-900 to-zinc-950 text-center space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 text-left max-w-4xl mx-auto">
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="mt-1 w-1.5 h-1.5 rounded-full bg-zinc-100 shrink-0" />
                <p className="text-sm text-zinc-300">"The algorithm rewards consistency."</p>
              </div>
              <div className="flex items-start gap-3">
                <div className="mt-1 w-1.5 h-1.5 rounded-full bg-zinc-100 shrink-0" />
                <p className="text-sm text-zinc-300">"Attention gets followers. Trust creates buyers."</p>
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="mt-1 w-1.5 h-1.5 rounded-full bg-zinc-100 shrink-0" />
                <p className="text-sm text-zinc-300">"Authority is built through repeated clarity."</p>
              </div>
              <div className="flex items-start gap-3">
                <div className="mt-1 w-1.5 h-1.5 rounded-full bg-zinc-100 shrink-0" />
                <p className="text-sm text-zinc-300">"Momentum is invisible before it becomes obvious."</p>
              </div>
            </div>
          </div>
          <div className="pt-12">
            <button className="px-8 py-4 bg-zinc-100 text-zinc-950 font-bold rounded-full hover:bg-zinc-200 transition-colors text-sm uppercase tracking-widest">
              Implement the System
            </button>
          </div>
        </div>
      </Section>

      {/* Footer */}
      <footer className="py-12 border-t border-zinc-900 text-center text-zinc-600 text-[10px] uppercase tracking-widest">
        &copy; 2026 Creator Operator Systems &bull; Internal Strategic Document
      </footer>
    </div>
  );
};

export default App;
