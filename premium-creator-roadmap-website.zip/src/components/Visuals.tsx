import React from 'react';
import { ArrowRight, CheckCircle2, XCircle, TrendingUp, TrendingDown, Lock, Unlock, Target, Users, Zap } from 'lucide-react';
import { cn } from '../lib/ui';

export const FlowDiagram = ({ steps }: { steps: { label: string; sub?: string }[] }) => {
  return (
    <div className="flex flex-col md:flex-row items-center justify-between gap-4 w-full py-12">
      {steps.map((step, idx) => (
        <React.Fragment key={idx}>
          <div className="flex flex-col items-center text-center max-w-[150px]">
            <div className="w-12 h-12 rounded-full border border-zinc-700 flex items-center justify-center bg-zinc-900 text-zinc-400 mb-3 font-mono text-sm">
              {idx + 1}
            </div>
            <div className="text-sm font-semibold text-zinc-100">{step.label}</div>
            {step.sub && <div className="text-[10px] text-zinc-500 mt-1">{step.sub}</div>}
          </div>
          {idx < steps.length - 1 && (
            <div className="hidden md:block text-zinc-700">
              <ArrowRight size={20} />
            </div>
          )}
        </React.Fragment>
      ))}
    </div>
  );
};

export const AuditMetric = ({ label, value, status, trend }: { label: string; value: string; status: 'strong' | 'weak'; trend: 'up' | 'down' }) => (
  <div className="p-4 rounded-xl border border-zinc-800 bg-zinc-900/30 flex justify-between items-center">
    <div>
      <div className="text-xs text-zinc-500 mb-1">{label}</div>
      <div className={cn("text-lg font-medium", status === 'strong' ? "text-zinc-100" : "text-zinc-400")}>{value}</div>
    </div>
    <div className={cn("flex items-center gap-2 px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider", 
      status === 'strong' ? "bg-emerald-500/10 text-emerald-500" : "bg-rose-500/10 text-rose-500")}>
      {status === 'strong' ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
      {status === 'strong' ? 'High' : 'Low'}
    </div>
  </div>
);

export const ComparisonCard = ({ weak, strong }: { weak: { title: string; points: string[] }; strong: { title: string; points: string[] } }) => (
  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full">
    <div className="p-6 rounded-2xl border border-rose-900/30 bg-rose-950/5">
      <div className="flex items-center gap-2 text-rose-500 mb-4 font-semibold">
        <XCircle size={18} />
        <span>{weak.title}</span>
      </div>
      <ul className="space-y-3">
        {weak.points.map((p, i) => (
          <li key={i} className="text-sm text-zinc-500 flex items-start gap-2">
            <div className="mt-1.5 w-1 h-1 rounded-full bg-rose-500 shrink-0" />
            {p}
          </li>
        ))}
      </ul>
    </div>
    <div className="p-6 rounded-2xl border border-emerald-900/30 bg-emerald-950/5">
      <div className="flex items-center gap-2 text-emerald-500 mb-4 font-semibold">
        <CheckCircle2 size={18} />
        <span>{strong.title}</span>
      </div>
      <ul className="space-y-3">
        {strong.points.map((p, i) => (
          <li key={i} className="text-sm text-zinc-100 flex items-start gap-2">
            <div className="mt-1.5 w-1 h-1 rounded-full bg-emerald-500 shrink-0" />
            {p}
          </li>
        ))}
      </ul>
    </div>
  </div>
);

export const RoadmapStep = ({ day, title, goal, content }: { day: string; title: string; goal: string; content: React.ReactNode }) => (
  <div className="relative pl-8 pb-12 border-l border-zinc-800 last:border-l-0">
    <div className="absolute -left-2 top-0 w-4 h-4 rounded-full bg-zinc-900 border border-zinc-700 flex items-center justify-center z-10">
      <div className="w-1.5 h-1.5 rounded-full bg-zinc-400" />
    </div>
    <div className="mb-1 text-xs font-mono text-zinc-500 uppercase tracking-widest">{day}</div>
    <div className="text-xl font-semibold text-zinc-100 mb-2">{title}</div>
    <div className="text-sm text-zinc-400 mb-6 italic">Goal: {goal}</div>
    <div className="text-zinc-300">
      {content}
    </div>
  </div>
);

export const SocialMockup = ({ platform, content, type = 'post' }: { platform: string; content: React.ReactNode; type?: 'post' | 'story' }) => (
  <div className={cn("border border-zinc-800 rounded-2xl overflow-hidden bg-zinc-900 shadow-2xl", type === 'story' ? "w-64 h-96" : "w-full max-w-md")}>
    <div className="p-3 border-b border-zinc-800 flex items-center gap-2">
      <div className="w-6 h-6 rounded-full bg-zinc-700" />
      <div className="text-[10px] font-bold text-zinc-400">{platform}</div>
    </div>
    <div className="p-4">
      {content}
    </div>
  </div>
);
